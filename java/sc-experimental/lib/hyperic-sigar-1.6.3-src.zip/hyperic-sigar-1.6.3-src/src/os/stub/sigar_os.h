#ifndef SIGAR_OS_H
#define SIGAR_OS_H

struct sigar_t {
    SIGAR_T_BASE;
};

#endif /* SIGAR_OS_H */
